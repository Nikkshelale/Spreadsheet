﻿using System;

class Program
{
    static string RemoveSpecialCharacters(string input)
    {
        string result = "";
        foreach (char c in input)
        {
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9'))
            {
                result += c;
            }
        }
        return result;
    }

    static void Main()
    {
        string str = "Senwell@$123";
        string result = RemoveSpecialCharacters(str);
        Console.WriteLine("String after removing special characters: " + result);

        Console.ReadLine(); 
    }
}
